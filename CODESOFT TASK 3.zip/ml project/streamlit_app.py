import streamlit as st
import pickle

model = pickle.load(open("model/model.pkl","rb"))
tfidf = pickle.load(open("model/tfidf.pkl","rb"))

st.title("Movie Genre Predictor")

plot = st.text_area("Enter movie plot")

if st.button("Predict"):
    vector = tfidf.transform([plot])
    result = model.predict(vector)
    st.success(result[0])