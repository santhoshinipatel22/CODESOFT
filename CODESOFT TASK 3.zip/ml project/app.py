import tkinter as tk
import pickle

# Load saved model and TF-IDF
model = pickle.load(open("model/model.pkl", "rb"))
tfidf = pickle.load(open("model/tfidf.pkl", "rb"))

def predict_genre():
    plot = text_box.get("1.0", tk.END).strip()

    if plot == "":
        result_label.config(text="Please enter a movie plot.")
        return

    vector = tfidf.transform([plot])
    prediction = model.predict(vector)

    result_label.config(text="Predicted Genre: " + prediction[0])

# Create window
root = tk.Tk()
root.title("Movie Genre Predictor")
root.geometry("500x350")

title = tk.Label(
    root,
    text="Movie Genre Predictor",
    font=("Arial", 16, "bold")
)
title.pack(pady=10)

tk.Label(root, text="Enter Movie Plot:").pack()

text_box = tk.Text(root, height=8, width=55)
text_box.pack(pady=10)

predict_button = tk.Button(
    root,
    text="Predict Genre",
    command=predict_genre
)
predict_button.pack(pady=10)

result_label = tk.Label(
    root,
    text="",
    font=("Arial", 12)
)
result_label.pack(pady=10)

root.mainloop()