import pickle

# Load model
model = pickle.load(open("model/model.pkl", "rb"))
tfidf = pickle.load(open("model/tfidf.pkl", "rb"))

# User input
plot = input("Enter movie plot: ")

# Convert text
plot_vector = tfidf.transform([plot])

# Predict
prediction = model.predict(plot_vector)

print("Predicted Genre:", prediction[0])